package com.example.e_study_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
